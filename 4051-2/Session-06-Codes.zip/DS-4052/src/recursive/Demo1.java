package recursive;

public class Demo1 {
    public static void main(String[] args) {

    }

    public static void f(int n){
        for (int i = 0; i < 2*n; i++) {
            for (int j = 0; j < 2*n; j++) {
                //DO_SOMETHING
                //DO_SOMETHING
            }
        }
    }

    public static void f2(int n){
        if(n>1){
            //DO_SOMETHING
            f2(n-1);
        }
    }
}

package recursive;

public class Hanoi {
    public static void main(String[] args) {
        hanoi(40, 'A', 'B', 'X');
    }

    public static void hanoi(int n, char from, char to, char aux){
        if(n == 1)
            System.out.println(from + " -> " + to);
        else {
            hanoi(n-1, from, aux, to);
            System.out.println(from + " -> " + to);
            hanoi(n-1, aux, to, from);
        }
    }
}

package recursive;

public class Fib {
    public static void main(String[] args) {
        int r = fib(60);
        System.out.println(r);
    }

    public static int fib(int n){
        if(n <= 2)
            return 1;
        return fib(n-1) + fib(n-2);
    }
}

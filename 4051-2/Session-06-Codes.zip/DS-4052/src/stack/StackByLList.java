package stack;

public class StackByLList {
    private Node top;
    private int size;

    public StackByLList() {
        size = 0;
    }

    public void push(int data){
        Node nn = new Node(data);
        nn.next = top;
        top = nn;
        size++;
    }

    public int pop(){
        if(size == 0)
            throw new RuntimeException("STACK IS EMPTY");
        int t = top.data;
        top = top.next;
        size--;
        return t;
    }

    public int peak(){
        if(size == 0)
            throw new RuntimeException("STACK IS EMPTY");
        return top.data;
    }
}

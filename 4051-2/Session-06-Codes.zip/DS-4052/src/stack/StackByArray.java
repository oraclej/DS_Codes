package stack;

public class StackByArray {
    int[] arr = new int[5];
    int top = -1;

    public void push(int data){
        if(top == arr.length - 1)
            throw new RuntimeException("Stack is FULL");
        else {
            top++;
            arr[top] = data;
        }
    }

    public int pop(){
        if(top == -1)
            throw new RuntimeException("Stack is Empty");
        else {
            top--;
            return arr[top + 1];
        }
    }

    public int peek(){
        if(top == -1)
            throw new RuntimeException("Stack is Empty");
        else
            return arr[top];
    }
}

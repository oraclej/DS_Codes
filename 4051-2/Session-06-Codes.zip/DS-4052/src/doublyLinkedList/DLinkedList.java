package doublyLinkedList;

public class DLinkedList {
    DNode head;
    private int size = 0;

    public void addFirst(int data){
        DNode nn = new DNode(data);
        size++;
        if(head == null)
            head = nn;
        else {
            nn.next = head;
            head.prev = nn;
            head = nn;
        }
    }

    public void addLast(int data){
        DNode nn = new DNode(data);
        size++;
        if(head == null)
            head = nn;
        else {
            DNode p = head;
            while (p.next != null)
                p = p.next;
            p.next = nn;
            nn.prev = p;
        }
    }

    public void print(){
        DNode p = head;
        while (p != null){
            System.out.println(p.data);
            p = p.next;
        }
    }

    public void removeLast(){
        if(head == null)
            return;
        if(head.next == null)
            head = null;
        else {
            DNode p = head;
            while (p.next != null)
                p = p.next;
            p.prev.next = null;
        }
        size--;
    }

    public void removeFirst(){
        if(head == null)
            return;
        if(head.next == null)
            head = null;
        else {
            head = head.next;
            head.prev = null;
        }
        size--;
    }

    public int getSize() {
        return size;
    }
}

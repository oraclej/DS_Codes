package doublyLinkedList;

public class Main {
    public static void main(String[] args) {
//        DNode n1 = new DNode(10);
//        DNode n2 = new DNode(20);
//        DNode n3 = new DNode(30);
//        n1.next = n2;
//        n2.next = n3;
//        n3.prev = n2;
//        n2.prev = n1;
        DLinkedList list = new DLinkedList();
//        list.head = n1;
        list.removeLast();
        list.addLast(60);
        list.addFirst(30);
        list.addFirst(20);
        list.addFirst(10);
        list.addLast(40);
        list.addLast(50);
        list.removeLast();
        list.print();
        System.out.println(list.getSize());
    }
}

package linkedList;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Demo1 {
    public static void main(String[] args) {
        List list = new LinkedList();
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < 500_000; i++) {
            list.add(0, 5);
        }
        long t2 = System.currentTimeMillis();
        long t = t2 - t1;
        System.out.println((t/1000) + "." + (t%1000));
    }
}

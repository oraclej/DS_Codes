package linkedList;

public class MyLinkedList {
    Node head;

    public MyLinkedList(Node head){
        this.head = head;
    }

    public void removeFirst(){
        if(head != null)
            head = head.next;
    }

    public int size(){
        if(head == null)
            return 0;
        int c = 1;
        Node p = head;
        while (p != null){
            p = p.next;
            c++;
        }
        return c;
    }

    public void removeLast(){
        if(head == null)
            return;
        if(head.next == null)
            head = null;
        else{
            Node p = head.next;
            Node q = head;
            while (p.next != null){
                q = p;
                p = p.next;
            }
            q.next = null;
        }
    }

    public void addNodeAtIndex(int index, int data){
        if(index < 0)
            return;

        Node p = head;
        Node q = null;
        Node nn = new Node(data);
        for (int i = 0; i < index - 1; i++) {
            if(p == null){
                q.next = nn;
                return;
            }
            q = p;
            p = p.next;
        }
        nn.next = p.next;
        p.next = nn;
    }

    public static void printRecursive(Node head){
        if(head != null) {
            printRecursive(head.next);
            System.out.println(head.data);
        }
    }
}

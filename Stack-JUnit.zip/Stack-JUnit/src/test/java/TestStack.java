import edu.iaun.StackByLList;
import org.junit.Test;

import static org.junit.Assert.*;

public class TestStack {
    @Test
    public void test1(){
        StackByLList stack = new StackByLList();
        stack.push(10);
        stack.push(10);
        stack.push(10);
        int s = stack.getSize();
        assertEquals(s , 3);
    }

    @Test
    public void test2(){
        StackByLList stack = new StackByLList();
        stack.push(10);
        stack.push(10);
        stack.push(10);
        stack.pop();
        stack.pop();
        stack.pop();
        int s = stack.getSize();
        assertEquals(s , 0);
    }

    @Test
    public void test3() {
        StackByLList stack = new StackByLList();
        stack.push(10);
        RuntimeException e =
        assertThrows(RuntimeException.class, ()->{
            stack.pop();
            stack.pop();
        });
        System.out.println(e.getMessage());
    }
    }

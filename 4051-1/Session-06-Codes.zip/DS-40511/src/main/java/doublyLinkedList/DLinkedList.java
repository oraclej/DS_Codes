package doublyLinkedList;

public class DLinkedList {
    private DNode head;
    private int size;

    public DLinkedList() {
        this.size = 0;
    }

    public int getSize() {
        return size;
    }

    public void addFirst(int data){
        DNode nn = new DNode(data);
        if(head == null){
            head = nn;
        }else {
            nn.next = head;
            head.prev = nn;
            nn.prev = null;
            head = nn;
        }
        size++;
    }

    public void print(){
        DNode p = head;
        while (p != null){
            System.out.println(p.data);
            p = p.next;
        }
    }

    public void addLast(int data){
        DNode nn = new DNode(data);
        if(head == null)
            head = nn;
        else {
            DNode p = head;
            while (p.next != null)
                p = p.next;
            nn.next = null;
            nn.prev = p;
            p.next = nn;
        }
        size++;
    }

    public void removeLast(){
        if(head == null)
            return;
        if(head.next == null)
            head = null;
        else {
            DNode p = head;
            while (p.next != null)
                p = p.next;
            p.prev.next = null;
        }
        size--;
    }

    public int findMaxNode(){
        DNode p = head;
        int max = -Integer.MAX_VALUE;
        for (int i = 0; i < size; i++) {
            if(p.data > max)
                max = p.data;
            p = p.next;
        }
        return max;
    }
}

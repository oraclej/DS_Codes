public class Power {
    public static void main(String[] args) {
        int r = power(2,3);
        System.out.println(r);
    }
    public static int power(int a, int b){
        if(b == 0)
            return 1;
        return a * power(a, b-1);
    }




    public static int power_NoRecursive(int a, int b){
        int p = 1;
        for (int i = 0; i < b ; i++)
            p *= a;
        return p;
    }
}
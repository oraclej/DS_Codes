package linkedList;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Demo1 {
    public static void main(String[] args) {
        List list = new LinkedList();
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < 1_000_000; i++) {
            list.add(0, 5);
        }
        long t2 = System.currentTimeMillis();
        System.out.print((t2 - t1) / 1000);
        System.out.print(".");
        System.out.println((t2 - t1) % 1000);
    }
}

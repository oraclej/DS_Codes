package linkedList;

public class MyLinkedList {
    Node head;

    public MyLinkedList(Node head) {
        this.head = head;
    }

    public void addNodeToFirst(int data) {
        Node nn = new Node(data);
        nn.next = head;
        head = nn;
    }

    public void removeFirst() {
        if (head != null)
            head = head.next;
    }

    public void addNodeAtIndex(int index, int data) {
        if (index > 0) {
            Node nn = new Node(data);
            Node p = head;
            Node q = null;
            for (int i = 0; i < index - 1; i++)
                if(p != null) {
                    q = p;
                    p = p.next;
                }else{
                    q.next = nn;
                }
            nn.next = p.next;
            p.next = nn;
        }else
            System.err.println("Invalid Index");
    }

    public static void printRecursive(Node head){
        if(head != null){
            printRecursive(head.next);
            System.out.println(head.data);
        }
    }

}

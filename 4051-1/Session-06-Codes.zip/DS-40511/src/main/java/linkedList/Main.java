package linkedList;

public class Main {
    public static void main(String[] args) {
        Node n1 = new Node(10);
        Node n2 = new Node(20);
        Node n3 = new Node(30);
        Node n4 = new Node(40);
        n1.next = n2;
        n2.next = n3;
        n3.next = n4;
        MyLinkedList linkedList = new MyLinkedList(n1);
//        linkedList.head = n1;
        linkedList.addNodeToFirst(5);
        linkedList.removeFirst();
        linkedList.removeFirst();
        linkedList.removeFirst();
        linkedList.removeFirst();
        linkedList.removeFirst();

        MyLinkedList.printRecursive(linkedList.head);
        //linkedList.print();
    }
}

public class Demo1 {
    public static void f(int n){
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                //DO_SOMETHING
            }
            for (int j = 0; j < n; j++) {
                //DO_SOMETHING
            }
        }
    }

    public void f2(int n){
        if(n > 1){
            System.out.println("hi");
            f2(n-1);
        }

    }
}

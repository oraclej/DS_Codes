package stack;

public class StackMain2 {
    public static void main(String[] args) {
        StackByLList stack = new StackByLList();
        stack.push(10);
        stack.push(20);
        stack.push(30);
        System.out.println(stack.peak());
        System.out.println(stack.peak());
        System.out.println(stack.peak());
        System.out.println(stack.peak());
        System.out.println(stack.pop());
        System.out.println(stack.peak());
        System.out.println(stack.pop());
        System.out.println(stack.pop());
    }
}

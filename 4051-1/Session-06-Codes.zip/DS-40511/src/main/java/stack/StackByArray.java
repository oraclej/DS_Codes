package stack;

public class StackByArray{
    private int[] arr;
    private int top = -1;

    public StackByArray(int maxSize) {
        arr = new int[maxSize];
    }

    public void push(int data){
        if(top == arr.length-1)
            throw new RuntimeException("STACK IS FULL");
        else {
            top++;
            arr[top] = data;
        }
    }

    public int pop(){
        if(top == -1)
            throw new RuntimeException("STACK IS EMPTY");
        else{
            top--;
            return arr[top+1];
        }
    }

    public int peek(){
        if(top == -1)
            throw new RuntimeException("STACK IS EMPTY");
        return arr[top];
    }

    public int getSize(){
        return top+1;
    }
}
